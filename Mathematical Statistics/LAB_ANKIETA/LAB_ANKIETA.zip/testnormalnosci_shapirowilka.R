#Test normalnośći Shapiro-Wilka
x = Ankieta$Wzrost
#H0: X ma rozkład normalny
#H1: ~H0
#TEST
pvalue=shapiro.test(x)$p.value
alpha = 0.05
pvalue
#jeśli p-value > alpha = brak podstaw do odrzucenia H0
#jeśli p-value <= alpha = odrzucamy H0, na korzyść H1
decyzja = ifelse(pvalue>alpha, "na poziomie istotnosci alfa brak podstaw do odrzucenia hipotety H0", "na poziomie istotności alfa odrzucamy H0, na korzyść H1")
decyzja