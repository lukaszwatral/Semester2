#X-zmienna badana
#G-zmienna grupujaca
x=c(20,33,35,25,30,27,28,30,33,20,24,18) #Ankieta$Wzrost
g=c(1,1,1,1,1,1,2,2,2,2,2,2) #Ankieta$Plec
#test Shapiro-Wilka grupami
#H0: zmienne w grupach maja rozklad zgodny z normalnym, H1: !H0
by(x,g,shapiro.test)

